# Introduction

MyShuttle is a sample Java/JEE application that provides booking system, admin portal and a control system for the drivers. The application uses entirely open source software including Linux, Java, Apache, and MySQL which creates a web front end, an order service, and an integration service.

![](https://vstsdemodata.visualstudio.com/aa2f337f-2dbf-4700-88e5-bf4f57f49cc6/_api/_versioncontrol/itemContent?repositoryId=14c9c1ce-2de9-4198-a252-3caca0305407&path=%2F1.png&version=GBmaster&contentOnly=true&__v=5)

